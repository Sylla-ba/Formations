### RAPPORT DU PROJET

### Open_Fact_Food

Ce projet a été réalisé par Bah Tanguy GOHO et Ndeye Sylla BA. Les tâches ont été réparties équitablement afin d'avoir une vue d'ensemble du projet. 
Ce projet est composé de 5 dossiers.
- Dossier Captures : ce dossier contient les différents résultats de nos requêtes  MDX (2 requêtes demandées et 4 requêtes au choix )
- Dossier ETL : ce dossier contient les fichiers .ktr qui représentent les différentes transformations ETL ainsi que les captures d'écran de nos résultats après les transformations ETL.
- Dossier Modélisation : ce dossier contient nos différents captures d'écran des modélisations UML et schémas de la base de diffusion.
- Dossier Schema_XML : ce dossier contient le code xml de nos deux cubes


### Choix de conception
Nous avons choisi d’adopter un modèle dimensionnel composé de deux cubes en raison de sa structure claire et intuitive. Ce choix se justifie par la nécessité d'établir une représentation accessible des données, facilitant ainsi l'analyse.  

La classe dimensionnelle "Date" par exemple est dotée d'attributs tels que l'année, le mois et le jour, et est reliée à la classe de fait ou table de fait “PRODUIT” par des clés étrangères correspondantes. 
Cette dernière est une dimension partagé et est utilisé dans les dimensions usages "Date creation" et "Date modification".


### Q4 : script sql de creation de la base de diffusion 
Nous avons choisi la base d'un des binomes ( bah tanguy ) comme base de diffusion ; a l'interieur, nous avons fait la creation des differentes tables :

### table fait_version_produit :

CREATE TABLE fait_version_produit_test ( num_seq_produit INT, num_seq_contributeur INT, num_seq_pnns INT,
 num_seq_date_modification INT, num_seq_date_creation INT, nb_version_produit INT,
 FOREIGN KEY (num_seq_produit) REFERENCES Dim_Produit(num_seq_produit), FOREIGN KEY (num_seq_contributeur) REFERENCES Dim_contributeur(num_seq_contributeur), FOREIGN KEY (num_seq_pnns) REFERENCES Dim_pnns(num_seq_pnns), FOREIGN KEY (num_seq_date_modification) REFERENCES Dim_date(num_seq_date), FOREIGN KEY (num_seq_date_creation) REFERENCES Dim_date(num_seq_date) )

### table Fait_produit :

CREATE TABLE fait_version_produit ( num_seq_produit INT, num_seq_contributeur INT, num_seq_pnns INT,
num_seq_date_creation INT, nb_prduit INT,
FOREIGN KEY (num_seq_produit) REFERENCES Dim_Produit(num_seq_produit), FOREIGN KEY (num_seq_contributeur) REFERENCES Dim_contributeur(num_seq_contributeur), FOREIGN KEY (num_seq_pnns) REFERENCES Dim_pnns(num_seq_pnns), FOREIGN KEY (num_seq_date_creation) REFERENCES Dim_date(num_seq_date) )

### table Dim_date :

CREATE TABLE Dim_date (
    num_seq_date INT AUTO_INCREMENT PRIMARY KEY,
    annee INT,
    mois INT,
    jour INT
);

### table Dim_pnns :

CREATE TABLE Dim_pnns (
    num_seq_pnns INT AUTO_INCREMENT PRIMARY KEY,
    pnns1 VARCHAR(254),
    pnns2 VARCHAR(254)
);


### table Dim_Produit :

CREATE TABLE Dim_Produit (
    num_seq_produit INT AUTO_INCREMENT PRIMARY KEY,
    codebare VARCHAR(254),
    nutriscore_fr VARCHAR(254)
);

### table Dim_contributeur :

CREATE TABLE Dim_Produit (
    num_seq_contributeur INT AUTO_INCREMENT PRIMARY KEY,
    pseudo VARCHAR(254),
);

### Q5 : Transformations Kettle
Nous avons ajouté des libellés à chaque composant kettle afin de faciliter la comprésentation des étapes de notre transformation.
Pour lancer l'exécution des traitements ETL, on lance dans un premier temps le fichier "loading my dims". Si ce dernier finit de s'exécuter, on pourra lancer ensuite les transformations pour les tables de fait.
Ce processus vise à éviter les erreurs liées à la migration des clés étrangères.


## Codes requêtes 

### Q6 Requête 1:  Nombre de produits par type de contributeur (rangées) et par année de création (colonnes);

SELECT
  {[Dim contributeur.Pseudo].[All Dim contributeur.Pseudos].Children} ON ROWS,
  {[Dim date.Annee].[All Dim date.Annees].Children} ON COLUMNS
FROM [Produit]
WHERE [Measures].[Nb prduit]

### Q6 Requête 2:  Nombre de versions de produits par mois et année (lignes) selon la présence ou non du Nutri-score (colonnes).

SELECT
  Crossjoin(
    {[Dim date.Annee].[All Dim date.Annees].Children},
    {[Dim date.Mois].[All Dim date.Moiss].Children}
  ) ON ROWS,
  {[Dim Produit.Nutriscore fr].[All Dim Produit.Nutriscore frs].Children} ON COLUMNS
FROM [version]
WHERE [Measures].[Nb version produit]


### Q7 Requête 1: Nombre total de versions de produits par année

select {[Measures].[Nb version produit]} ON COLUMNS,
  {[Dim date.Annee].[All Dim date.Annees].Children} ON ROWS
from [version]

### Q7 Requête 2: Nombre de versions de produits pour chaque combinaison de mois, année et nutriscore pour l’année 2014

SELECT
  Crossjoin(
    {[Dim date.Annee].[2014]},
    {[Dim date.Mois].[All Dim date.Moiss].Children}
  ) ON ROWS,
  {[Dim Produit.Nutriscore fr].[All Dim Produit.Nutriscore frs].Children} ON COLUMNS
FROM [version]
WHERE [Measures].[Nb version produit]

### Q7 Requête 3: Nombre de versions par mois (lignes) et pnns1 (colonnes) des produits créés en 2012.

SELECT
  {[Dim date.Mois].[All Dim date.Moiss].Children} ON ROWS,
  {[Dim pnns.Pnns1].[All Dim pnns.Pnns1s].Children} ON COLUMNS
FROM [versionPnns]
WHERE ([Dim date.Annee].[2012], [Measures].[Nb version produit])

### Q7 Requête 4:  Nombre de produits crée en 2014 (colonnes ) par type de contributeur (rangées).

SELECT {[Dim date.Annee].[2014]} ON COLUMNS,
  {[Dim contributeur.Pseudo].[All Dim contributeur.Pseudos].Children} ON ROWS
FROM [Produit]
WHERE [Measures].[Nb prduit]





