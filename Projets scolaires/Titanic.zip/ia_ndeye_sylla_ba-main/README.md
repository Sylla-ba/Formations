# Ndeye Sylla BA
# BAH Tanguy GOHO

Sujet du TP 1_2:

Exercise 1 : First hand on a neural network

Objective : Understand how the basic blocks of a simple neural network work.
First, read the following code to grasp the main idea of the learning of the XOR gate : understandingXOR-with-keras-and-tensorlow. Then, run and understand the provided python code (the XOR_TP12.ipynb
file in moodle) in a Jupyter notebook in order to compute the XOR gate. Finally, based on the following
lines, explain how the neural network is trained.
sgd = tf . keras . optimizers . SGD ( learning_rate =0.1)
model . compile ( loss = ’ binary_crossentropy ’ ,
optimizer = sgd ,
metrics =[ ’ accuracy ’ ])
After quickly reminding their truth tables, extend the code for the OR gate, the AND gate, the NOT gate
and the NAND gate. To help you with your report, you can try to answer the following questions :
— What is the influence of the parameter epochs in the function fit ? Is there an optimal value ?
— Does changing the values for the number of epochs, the number of neurons or the layers affect the
training ? Experiment with varying epochs, number of neurons and layers. Write your observation in
the jupyter notebook.
— What is the batch_size parameter in the function fit ?
— Is it possible to chose a smaller-size hidden layer to realize the gates ? Why ?
— Explore other activation functions, loss functions and optimizers. How they affect training the network.

Exercise 2 : Building a neural network to classify images

Objective : Build a multi-layer perceptron to classify images.
The Fashion MNIST dataset is a collection of 70,000 gray-scale images in 10 categories. Here we propose
to construct and train a multi-layer perceptron to classify these images in the 10 categories. The dataset
is widely used for image classification (https://keras.io/datasets/) and even used as a baseline in nowdays
baseline for some classification models.
Here, to help you with your report, we advise you to follow this three-stepped protocol :
— First, explore your dataset. Observe some images, calculate some basic statistics on the data, look at
the labels, etc.
— Then, run the code (https://www.tensorflow.org/tutorials/keras/classification) to train the classifier
and label the images. Be sure to understand what each line is doing.
— Finally, toy with the different parameters (including, but not limited to topology, layer size, activation
functions, etc). Observe the effects on the classification accuracy and run time, and explain why
changing the parameters the way you did produced the changes you observed.

Exercise 3 : Building a neural network to classify texts

Objective : Understand the notion of over-fitting and under-fitting.
In this exercise, we propose you to witness the phenomena of over-fitting and under-fitting. To do so,
you will train a MLP (see Exercise 2) on the IMDB dataset and classify its reviews. This dataset is made of
50,000 movies reviews from IMDB, labeled by sentiment : positive or negative. You can find more information
here : https://keras.io/datasets/.
Like the previous exercise, we propose you to follow an classical approach to the problem 
— Explore the dataset and calculate some basic statistics. Try to recover at least one review with the
help of the dictionary mapping (based on this Tensorflow tutorial).
— Experiment with different network sizes : try to reduce or increase the network size, and observe the
effect on the performance (accuracy of the prediction) and the running time.
— Change the network parameters to demonstrate the effects of over-fitting. Example.
As an additional resource, you can find here some strategies that help preventing over-fitting


## Getting started

